# Gabriel Libwama — Personal Brand Website

A responsive single-page professional website for Gabriel Libwama,
Accountant | Finance Professional.

## Included
- Brand-consistent hero section
- About and professional philosophy
- Core values
- Services / areas of expertise
- "Giving Meaning to Numbers" insights section
- Professional journey
- Contact section with clickable phone and email
- Mobile-responsive navigation
- Brand colors: Navy, Emerald, Gold, Soft Grey
- Typography: DM Sans + Playfair Display

## How to use
Open `index.html` in a browser to preview the website.

## Next development steps
1. Add a professional profile photograph.
2. Add LinkedIn and other social links.
3. Add downloadable CV.
4. Create individual article pages for the insights.
5. Add a portfolio/case studies section.
6. Connect a custom domain and hosting.
